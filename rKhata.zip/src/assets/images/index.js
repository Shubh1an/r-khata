import PlayStore from './playstore 1.png'
import AppStore from './appstore 1.png'
import MobImage from './nowewewe 1.png'
export const images= {
    PlayStore,
    AppStore,
    MobImage
}