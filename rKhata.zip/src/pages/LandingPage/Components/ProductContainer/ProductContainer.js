import React from 'react'
import CommonContainer from '../../../../components/CommonContainer'

const ProductContainer = () => {
  return (
    <div>
        <CommonContainer>
            <div className='grid-container'>
                <div className='px-6 pt-7 bg-yellow-500 item-a'>
                    <p className='md:text-3xl text-lg text-white font-semibold mb-5'>Products for Sale:</p>
                    <p className='mb-28 text-left text-sm md:text-base'>Discover an extensive range of products available for purchase on Rkhata. From the latest gadgets and trendy fashion items to home appliances and health & wellness essentials, we have it all. Our diverse catalog ensures that you'll always find something that suits your style and meets your requirements.</p>
                </div>
                <div className='px-6 pt-7 bg-yellow-500 item-a'>
                    <p className='md:text-3xl text-lg text-white font-semibold mb-5'>Products for Sale:</p>
                    <p className='mb-28 text-left text-sm md:text-base'>Discover an extensive range of products available for purchase on Rkhata. From the latest gadgets and trendy fashion items to home appliances and health & wellness essentials, we have it all. Our diverse catalog ensures that you'll always find something that suits your style and meets your requirements.</p>
                </div>
                <div className='px-6 pt-7 bg-yellow-500 item-c'>
                    <p className='md:text-3xl text-lg text-white font-semibold mb-5'>Products for Sale:</p>
                    <p className='mb-28 text-left text-sm md:text-base'>Discover an extensive range of products available for purchase on Rkhata. From the latest gadgets and trendy fashion items to home appliances and health & wellness essentials, we have it all. Our diverse catalog ensures that you'll always find something that suits your style and meets your requirements.</p>
                </div>
                <div className='px-6 pt-7 bg-yellow-500 item-d'>
                    <p className='md:text-3xl text-lg text-white font-semibold mb-5'>Products for Sale:</p>
                    <p className='mb-28 text-left text-sm md:text-base'>Discover an extensive range of products available for purchase on Rkhata. From the latest gadgets and trendy fashion items to home appliances and health & wellness essentials, we have it all. Our diverse catalog ensures that you'll always find something that suits your style and meets your requirements.</p>
                </div>
            
                
               
            </div>
        </CommonContainer>
    </div>
  )
}

export default ProductContainer